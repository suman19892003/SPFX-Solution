define([], function() {
  return {
    "Title": "SpfxMegaMenuApplicationCustomizer"
  }
});