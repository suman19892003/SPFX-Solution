declare interface ISpfxMegaMenuApplicationCustomizerStrings {
  Title: string;
}

declare module 'SpfxMegaMenuApplicationCustomizerStrings' {
  const strings: ISpfxMegaMenuApplicationCustomizerStrings;
  export = strings;
}
