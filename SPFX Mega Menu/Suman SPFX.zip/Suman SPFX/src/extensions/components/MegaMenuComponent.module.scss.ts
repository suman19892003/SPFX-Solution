/* tslint:disable */
require("./MegaMenuComponent.module.css");
const styles = {
  'od-ItemsScopeList-page': 'od-ItemsScopeList-page_f587a796',
  'od-ItemsScopeList-content-sticky': 'od-ItemsScopeList-content-sticky_f587a796',
  'od-ItemContent-header': 'od-ItemContent-header_f587a796',
  container: 'container_f587a796',
  loadersize: 'loadersize_f587a796',
  svgLoader: 'svgLoader_f587a796',
  spin: 'spin_f587a796',
  divLoader: 'divLoader_f587a796',
  teamLiStyle: 'teamLiStyle_f587a796',
  'od-ItemContent-title': 'od-ItemContent-title_f587a796',
  liclass: 'liclass_f587a796',
  menusub: 'menusub_f587a796',
  menucategory: 'menucategory_f587a796',
  menucol1: 'menucol1_f587a796',
  menucol2: 'menucol2_f587a796',
  menucol3: 'menucol3_f587a796',
  menucol4: 'menucol4_f587a796',
  teamliNew: 'teamliNew_f587a796',
  headerTeam: 'headerTeam_f587a796'
};

export default styles;
/* tslint:enable */