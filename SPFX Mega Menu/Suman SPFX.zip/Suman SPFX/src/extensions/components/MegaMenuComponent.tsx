import * as React from "react";
import * as ReactDOM from "react-dom";
import * as jQuery from 'jQuery';
import styles from "./MegaMenuComponent.module.scss";
import { sp } from "@pnp/sp";
import { SPHttpClient, SPHttpClientConfiguration, SPHttpClientResponse, ODataVersion, ISPHttpClientConfiguration, ISPHttpClientOptions, ISPHttpClientBatchOptions, SPHttpClientBatch, ISPHttpClientBatchCreationOptions } from '@microsoft/sp-http';



export interface IMegaMenuComponentState 
{
  followedSites: any[];
  bookmarkSites: any[];
  profileUrl: string;
  externalSharingDisplayStyle: string;
  primaryOwnerEmail: string;
  primaryOwnerDisplayName: string;
  teamURL:string;
  isTeamExists:boolean;
  isExternallyShared:boolean;
  isLoading: boolean;
  companyLogoUrl: string;
  rootWebUrl: string;
  IsPrimaryOwner :string;
  SiteOwnerGroupInfo : string;
}
  
export interface IMegaMenuComponentProps 
{
  email: string;
  webAbsoluteUrl: string;
  SPOHttpClient: SPHttpClient;
}

      export default class MegaMenuComponent extends React.Component<IMegaMenuComponentProps, IMegaMenuComponentState> {

        constructor(props: any,state:IMegaMenuComponentState) {
          super(props);
          
          this.state = {
            followedSites: [],
            bookmarkSites: [],
            profileUrl:"",
            externalSharingDisplayStyle:"",
            primaryOwnerEmail:"",
            primaryOwnerDisplayName:"",
            teamURL:"",
            isTeamExists:false,
            isExternallyShared:false,
            isLoading: false,
            companyLogoUrl: "",
            rootWebUrl: "",
            IsPrimaryOwner:"false",
            SiteOwnerGroupInfo:"false"
          };
          this.invokeRestServices();
          
          this.makeSPHttpClientBatchRequest_AssociatedWeb();
          
          this.getTeamInfo();     
          
        }

        public componentDidMount(){
          
          setTimeout(()=>{
            this.setState({isLoading: false});
          },4000);
          
        }


        private makeSPHttpClientBatchRequest_AssociatedWeb(): void {
          
            const spHttpClient: SPHttpClient = this.props.SPOHttpClient;
            const currentWebUrl: string = this.props.webAbsoluteUrl;
            const spBatchCreationOpts: ISPHttpClientBatchCreationOptions = { webUrl: currentWebUrl };
            const spBatch: SPHttpClientBatch = spHttpClient.beginBatch(spBatchCreationOpts);
            

            this.setState({companyLogoUrl: "https://gcpat.sharepoint.com/sites/SP/Code/Branding/images/GCP_Logo.png"});
            const getMyProperties: Promise<SPHttpClientResponse> = spBatch.get(`${currentWebUrl}/_api/SP.UserProfiles.PeopleManager/GetMyProperties?$select=DisplayName`, SPHttpClientBatch.configurations.v1);
            const getSiteCollectionUrl: Promise<SPHttpClientResponse> = spBatch.get(`${currentWebUrl}/_api/web/firstUniqueAncestorSecurableObject?$select=Url`, SPHttpClientBatch.configurations.v1);
            const getAssociatedOwnerGroup: Promise<SPHttpClientResponse> = spBatch.get(`${currentWebUrl}/_api/web/AssociatedOwnerGroup?$select=Title,ID`, SPHttpClientBatch.configurations.v1);
            const getWebTitle: Promise<SPHttpClientResponse> = spBatch.get(`${currentWebUrl}/_api/web/title`, SPHttpClientBatch.configurations.v1);
            const getProfileSite: Promise<SPHttpClientResponse> = spBatch.get(`${currentWebUrl}/_api/sp.userprofiles.peoplemanager/getmyproperties/UserUrl`, SPHttpClientBatch.configurations.v1);
            const currentTime: string = new Date().toString();
              
        
            spBatch.execute().then(() => {
              
              getMyProperties.then((response: SPHttpClientResponse) => {
                response.json().then((props: any) => {
                  console.log("DisplayName " + props.DisplayName);
                });
              });

              getSiteCollectionUrl.then((response: SPHttpClientResponse) => {
                response.json().then((props: any) => {
                  this.setState({rootWebUrl: props.Url});
                  this.makeSPHttpClientBatchRequest_SiteInformationWeb();
                });
              });
            
              getAssociatedOwnerGroup.then((response: SPHttpClientResponse) => {
                response.json().then((props: any) => {
                  console.log("AssociatedOwnerGroup ID: " + props.Id  + " Title: " + props.Title);
                });
              });


              getProfileSite.then((response: SPHttpClientResponse) => {
                response.json().then((props: any) => {
                  console.log("User Profile Site: " + props.value);
                  this.setState({profileUrl: props.value});
                });
              });

              getWebTitle.then((response: SPHttpClientResponse) => {
                 response.json().then((props: any) => {
                  console.log("Web Title" + props.value);
                });
              });

            });
          
          }

          private makeSPHttpClientBatchRequest_SiteInformationWeb(): void {

            const spHttpClient: SPHttpClient = this.props.SPOHttpClient;
            const rootWebUrl: string = this.state.rootWebUrl;
            const siteUrl="https://gcpat.sharepoint.com/sites/SP";
            const spBatchCreationOpts: ISPHttpClientBatchCreationOptions = { webUrl: siteUrl };
            const spBatch: SPHttpClientBatch = spHttpClient.beginBatch(spBatchCreationOpts);

            const getSiteOwnerGroupInformation: Promise<SPHttpClientResponse> = spBatch.get(`${siteUrl}/_api/web/lists/getbytitle('SitesInfo')/items?$select=AssociatedOwnerGroup&$filter=URL_text eq '${rootWebUrl}'`, SPHttpClientBatch.configurations.v1);
            const getPrimarySiteOwnerInformation: Promise<SPHttpClientResponse> = spBatch.get(`${siteUrl}/_api/web/lists/getbytitle('SitesInfo')/items?$select=PrimaryOwner/Title,PrimaryOwner/EMail&$expand=PrimaryOwner/Id&$filter=URL_text eq '${rootWebUrl}'`, SPHttpClientBatch.configurations.v1);
            const getExternalSharingInformation: Promise<SPHttpClientResponse> = spBatch.get(`${siteUrl}/_api/web/lists/getbytitle('SitesInfo')/items?$select=External_x0020_Sharing_x0020_Sta&$filter=URL_text eq '${rootWebUrl}'`, SPHttpClientBatch.configurations.v1);
 
            spBatch.execute().then(() => {

            
              getPrimarySiteOwnerInformation.then((response: SPHttpClientResponse) => {
                response.json().then((props: any) => {
                 
                  if(props.value[0].PrimaryOwner === undefined)
                  {
                    this.getAssociatedWebOwnerInformation();
                  }
                  else
                  {
                    var mailToContact: string ="mailto:";
                   
                  var email: string = props.value[0].PrimaryOwner[0].EMail;
                  if(email.length > 0)
                  {
                    
                  var PrimaryOwnerSiteLink="";
                  PrimaryOwnerSiteLink += '<a style ="padding: 0px; display: inline;" href="mailto:' + email +'">' + props.value[0].PrimaryOwner[0].Title + '</a>';
                  jQuery("#siteOwnerTitle").html("Site Owner(s) : " + PrimaryOwnerSiteLink);

                  }  
                    console.log("PrimarySiteOwner Title: " + props.value[0].PrimaryOwner[0].Title + " Email: " + props.value[0].PrimaryOwner[0].EMail);
                  
                  }
                  
                });
               
              });   

              getSiteOwnerGroupInformation.then((response: SPHttpClientResponse) => {
                response.json().then((props: any) => {
                  if(props.value.length>0)
                  {
                    if(this.state.IsPrimaryOwner == "false")
                    {
                      console.log("IS Primary owner :" + this.state.IsPrimaryOwner);
                      console.log("Associated OwnerGroup Title Site Info: " + props.value[0].AssociatedOwnerGroup);
                      var o365AdminGroupTitle: string = " Admin (Office 365 Group)"
                      var AssociatedOwnerGroup: string = props.value[0].AssociatedOwnerGroup;
                      this.setState({primaryOwnerDisplayName: AssociatedOwnerGroup.concat(o365AdminGroupTitle)});
                      this.setState({primaryOwnerEmail: ""});
                      this.setState({SiteOwnerGroupInfo: "true"});
                    }
                   
                  }
                });
              });
 
              getExternalSharingInformation.then((response: SPHttpClientResponse) => {
                response.json().then((props: any) => {
                if(props.value.length>0)
                {
                   if(props.value[0].External_x0020_Sharing_x0020_Sta=="ExternalUserSharingOnly")
                   {
                    this.setState({isExternallyShared: true});
                  }
                  else
                  {
                    this.setState({isExternallyShared: false});
                  }
                }
                });
              });
 
            });
 
          }


          private getAssociatedWebOwnerInformation(): void {
            
            const spHttpClient: SPHttpClient = this.props.SPOHttpClient;
            const currentWebUrl: string = this.props.webAbsoluteUrl;
            const spBatchCreationOpts: ISPHttpClientBatchCreationOptions = { webUrl: currentWebUrl };
            const spBatch: SPHttpClientBatch = spHttpClient.beginBatch(spBatchCreationOpts);
            const getAssociatedOwnerGroup: Promise<SPHttpClientResponse> = spBatch.get(`${currentWebUrl}/_api/web/AssociatedOwnerGroup?$select=Title,ID`, SPHttpClientBatch.configurations.v1);
            
            spBatch.execute().then(() => {
            
              getAssociatedOwnerGroup.then((response: SPHttpClientResponse) => {
                response.json().then((props: any) => {
                 
                    if(props.Title === undefined) 
                    { 
                      this.setState({primaryOwnerDisplayName: "Asscociated OwnerGroup not Available"});
                      this.setState({primaryOwnerEmail: ""});
                      var messagetodisplay = "Asscociated OwnerGroup not Available"
                      var emptyemail ="#";
                      var PrimaryOwnerblankSiteLink="";
                      PrimaryOwnerblankSiteLink += '<a style ="padding: 0px; display: inline;" href="' + emptyemail +'">' + messagetodisplay + '</a>';
                      jQuery("#siteOwnerTitle").html("Site Owner(s) : " + PrimaryOwnerblankSiteLink);
                    
                    } 
                    else
                    {
                      console.log("SiteOwnerGroupInfo" + this.state.SiteOwnerGroupInfo);
                      console.log("AssociatedOwnerGroup ID: " + props.Id  + " Title: " + props.Title);
                      this.getAssociatedWebOwnerGroupMembersInformation(props.Id,props.Title)
                    }
                  
                       
                });
              });

            });

          }

          private getAssociatedWebOwnerGroupMembersInformation(GroupID,GroupTitle) : void {

            const spHttpClient: SPHttpClient = this.props.SPOHttpClient;
            const currentWebUrl: string = this.props.webAbsoluteUrl;
            var restUrl=currentWebUrl + "/_api/web/sitegroups/getbyname('" + GroupTitle +"')/users?$select=Title,Email";
            restUrl+="&$filter=(substringof('Sharepoint',Title) eq false) and (substringof('Service',Title) eq false) and (Email ne '')";
            const spBatchCreationOpts: ISPHttpClientBatchCreationOptions = { webUrl: restUrl };
            const spBatch: SPHttpClientBatch = spHttpClient.beginBatch(spBatchCreationOpts);
            const getAssociatedOwnerGroupMembers: Promise<SPHttpClientResponse> = spBatch.get(`${restUrl}`, SPHttpClientBatch.configurations.v1);
            
            spBatch.execute().then(() => {
            
              getAssociatedOwnerGroupMembers.then((response: SPHttpClientResponse) => {
                response.json().then((props: any) => {
                  
                  
                    if(props.value.length > 0)
                  {
                   
                    var itemHeaderOwnersLimit = 3 
                    var siteOwnerLink="";
                    var siteOwnerGroupUrl ="";
                    siteOwnerGroupUrl = currentWebUrl;
  
                    if(props.value.length > 3)
                    {
                     itemHeaderOwnersLimit = 3;
                    }
                    else
                    {
                     itemHeaderOwnersLimit = props.value.length;
                    }
                   
                    for (var i = 0; i < itemHeaderOwnersLimit; i++) 
                    {
                     var userEmail = props.value[i].Email;
                     var userDisplayName = props.value[i].Title;
                     console.log("AssociatedOwnerMembers Email : " + props.value[i].Email);
                     console.log("AssociatedOwnerMembers Title : " + props.value[i].Title);
                     
                      if(i === (itemHeaderOwnersLimit-1))
                      {
                       siteOwnerLink += '<a style ="padding: 0px; display: inline;" href="mailto:' + userEmail +'">' + userDisplayName + '</a>';      
                      }
                      else
                      {
                       siteOwnerLink +='<a style ="padding: 0px; display: inline;" href="mailto:' + userEmail +'">' + userDisplayName + '</a>&nbsp; ; &nbsp;';      
                      }
                    }
               
                    if(GroupID >0)
                    {
                    siteOwnerGroupUrl = siteOwnerGroupUrl + "/_layouts/15/people.aspx?MembershipGroupId="+GroupID;
                    siteOwnerLink +='<a target="_blank" style ="padding: 10px; display: inline;" href="' + siteOwnerGroupUrl +'">[View Owners]</a>'
                    }
                    
                     jQuery("#siteOwnerTitle").html("Site Owner(s) : " + siteOwnerLink);
  
                  }
  
                });
              });
  
            });
  
           }



        private getFollowedSites(): Promise<any> {  
            return new Promise<any>((resolve: (data:any) => void, reject: (error: any) => void): void => {  
             var restUrl="";
             restUrl="https://gcpat.sharepoint.com/_api/social.following/my/followed(types=4)";
             jQuery.ajax({
                url:restUrl,
                method:"GET",
                headers:{"Accept":"application/json;odata=verbose"}
              }).then((response) => {  
                    resolve(response);  
                }, (error: any): void => {  
                  reject(error);  
                });  
            });  
          }
     
          private invokeRestServices()
          {
            var component = this;

            this.getBookmarkUserSites().then((data) =>{
              var bookmarkSites =[];
              var bookmarkItem ={};
              data.d.results.map((item,index) => { 
                  if(index < 10)
                  {
                  bookmarkItem ={};
                  bookmarkItem["Uri"]=item.URL.Url;
                  bookmarkItem["Name"]=item.URL.Description;
                  bookmarkSites.push(bookmarkItem);
                  }
                });
              bookmarkItem ={};
              bookmarkItem["Uri"]="https://gcpat.sharepoint.com/Lists/UserLinks/NewForm.aspx";
              bookmarkItem["Name"]="Add a Bookmark";
              bookmarkSites.push(bookmarkItem);
              component.setState({bookmarkSites: bookmarkSites}); 
            });
          
       
            this.getFollowedSites().then((data)=>{
              var followedSiteLink ="";
              var followedSites =[];
              var followedItem ={};
              var followedSitesCount = data.d.Followed.results.length;
              
               data.d.Followed.results.map((item,index) => { 
                 if(index < 10)
                 {
                  followedItem ={};
                  followedItem["Uri"]=item.Uri;
                  followedItem["Name"]=item.Name;
                  followedSites.push(followedItem);
                 }
               });
               
               if(followedSitesCount > 10)
               {
                followedItem ={};
                followedItem["Uri"]="https://gcpat.sharepoint.com/_layouts/15/sharepoint.aspx?v=following";
                followedItem["Name"]="All Following Sites...";
                followedSites.push(followedItem);
               }
        
              component.setState({followedSites: followedSites});
             }); 
          }

          private getBookmarkUserSites(): Promise<any> {  
              return new Promise<any>((resolve: (data:any) => void, reject: (error: any) => void): void => {  
              
              var restUrl="https://gcpat.sharepoint.com/_api/web/lists/getbyTitle('My GCP Links')/items?$filter=Author/EMail eq'" + this.props.email +"'&$expand=Author&$select=Author/EMail,*";
                     
               jQuery.ajax({
                  url:restUrl,
                  method:"GET",
                  headers:{"Accept":"application/json;odata=verbose"}
                }).then((response) => {  
                      resolve(response);
                  }, (error: any): void => {  
                    reject(error);  
                  });  
              });  
            }

            private getTeamInfo(): Promise<any> {  
                return new Promise<any>((resolve: (data:any) => void, reject: (error: any) => void): void => {  

                var UrlToSearch = "https://gcpat.sharepoint.com/sites/Workflows/M365RequestApp";
                //var siteUrl = this.props.webAbsoluteUrl;
                var restUrl=UrlToSearch + "/_api/web/lists/getbytitle('TeamInfo')/items?$select=SiteURL,TeamURL";
                restUrl+="&$filter=SiteURL eq '" + this.props.webAbsoluteUrl +"'";
           
                 jQuery.ajax({
                    url:restUrl,
                    method:"GET",
                    headers:{"Accept":"application/json;odata=verbose"}
                  }).then((response) => {
                        //alert(response.d.TeamURL); 
                      
                        if(response.d.results.length>0){
                          this.setState({teamURL:response.d.results[0].TeamURL});
                          this.setState({isTeamExists:true})
                          resolve(response.d.results[0].TeamURL);
                        }
                        else{
                          this.setState({teamURL:'#'});
                          this.setState({isTeamExists:false})
                        }
                              
                    }, (error: any): void => {  
                      //reject(error);  
                    });  
                });
              }


      
              public render(): React.ReactElement<{}> {
      
                
                var gcpLogoLiStyle:any = {
                  marginTop: "5px", 
                  marginLeft: "10px",
                  float: "left"
                 };
            
                var anchorLogoItemStyle:any = {
                  textDecoration:"none",
                  padding:"0px",
                  backgroundColor:"white"
                };
            
            
                var externalSharingLiStyle:any = {
                  marginTop: "14px",
                  marginBottom: "11px", 
                  marginLeft: "10px"
                };
            
                var externalSharingSpanStyle:any = {
                  color:"red",
                  backgroundColor:"white",
                  fontWeight:"bold"
                  
                };

                var externalSharingSpanNone:any = {
                  display: "none"
                };
            
                var siteOwnerLiStyle:any = {
                  marginTop: "14px",
                  marginBottom: "11px", 
                  marginLeft: "10px"
                };
            
                
                var siteOwnerAnchorStyle:any = {
                  padding: "0px",
                  display: "inline"
                };

                var teamAnchorStyle:any = {
                  padding: "0px",
                  display: "inline",
                  color:"darkcyan"
                };

                var teamAnchorStylenone:any = {
                  display: "none"
                };
            
                
                var siteOwnerSpanStyle:any = {
                  backgroundColor:"white"
                };
               
                var megaMenuLiStyle:any = {
                  float: "right"
                };
            
                var megaMenuImgStyle:any = {
                  height: "22px"
                };
                
                return (
                    <React.Fragment>
                    
                                    {
                                                 
                                      <nav>
                                      <div className={styles.container}>
                                      <ul id="topnav">
                                       <li className={styles.liclass} style={gcpLogoLiStyle}>
                                        <a style={anchorLogoItemStyle} href="https://gcpat.sharepoint.com" target="_blank">
                                           <img width='260px' src="https://gcpat.sharepoint.com/sites/SP/Code/Branding/images/GCP_Logo.png"></img>
                                           
                                        </a>
                                       </li>
                                       <li className={styles.liclass} style={externalSharingLiStyle}>
                                         <span id="externalSharing" style={this.state.isExternallyShared?externalSharingSpanStyle:externalSharingSpanNone}>
                                            This Site is Externally shared
                                         </span>
                                       </li>
                                       <li className={styles.liclass} style={siteOwnerLiStyle}>
                                         <span id="siteOwnerTitle" style={siteOwnerSpanStyle}>
                                         Site Owners : <a style={siteOwnerAnchorStyle} href={this.state.primaryOwnerEmail}>{this.state.primaryOwnerDisplayName}</a>
                                         </span>
                                       </li>                  
                                       
                                       <li className={styles.liclass} style={megaMenuLiStyle}>
                    
                                          <a href="#"><img style={megaMenuImgStyle} src="/_layouts/15/images/favicon.ico"></img>
                                          </a>
                                         <div className={styles.menusub}>
                                            <div className={styles.menucol1}>
                                              <span className={styles.menucategory}>Search</span>
                                               <ul id="searchLinks">
                                               <li><a href="https://gcpat.sharepoint.com/search">Search All GCP SharePoint</a></li>
                                               <li><a href="https://gcpat.sharepoint.com/search/Pages/advanced.aspx">Search All GCP SharePoint - Advanced</a></li>
                                               <li><a href="https://gcpat.sharepoint.com/search/Pages/Employee-Directory.aspx">People Search</a></li>
                                               </ul>
                                
                                               <span className={styles.menucategory}>Profile</span>
                                               <ul id="profileLinks">
                                               <li><a href={this.state.profileUrl}>My Profile</a></li>
                                               </ul>
                                            </div>
                                           <div className={styles.menucol1}>
                                             <span className={styles.menucategory}>Bookmarks</span>
                                             <ul id="bookmarkLinks">
                                             {this.state.bookmarkSites.map((obj, index) => (
                                                <li><a href={obj.Uri}>{obj.Name}</a></li>
                                             ))}

                                             </ul>
                                           </div>
                                           <div className={styles.menucol1}>
                                             <span className={styles.menucategory}>My SharePoint Sites</span>
                                             <ul id="sharePointLinks">
                                             <li><a href="https://gcpat.sharepoint.com/_layouts/15/sharepoint.aspx">My Frequent, Recent, and Suggested Sites</a></li>
                                              <li><a href="https://gcpat.sharepoint.com/search/Pages/My-Sites.aspx?k=">All My SharePoint Sites</a></li>
                                              <li><a href="https://gcpat.sharepoint.com/search/Pages/My-Top-Level-Sites.aspx?k=">All My SharePoint Top Level Sites</a></li>
                                              <li><a href="https://gcpat.sharepoint.com/sites/SP/SitePages/GlobalSiteDirectory.aspx">GCP Site Directory</a></li>
                                             </ul>
                                           </div>
                                           <div className={styles.menucol1}>
                                             <span className={styles.menucategory}>Following Sites</span>
                                             <ul id="FollowingSiteLinks">
                                             {this.state.followedSites.map((obj, index) => (
                                                <li><a href={obj.Uri}>{obj.Name}</a></li>
                                              ))}
                                             
                                             </ul>
                                           </div>
                                          </div></li>                  
                                          <li className={styles.teamLiStyle}>
                                  <span id="teamLink">
                                    <h4 className={styles.headerTeam} ><a style={this.state.isTeamExists?teamAnchorStyle:teamAnchorStylenone} target="_blank"
                                        href={this.state.teamURL}>Open in teams
                                     </a></h4>
                                      </span>
                                        </li>
                                          </ul></div></nav>  }
                                          </React.Fragment>
                                    );                
               }  
            }

