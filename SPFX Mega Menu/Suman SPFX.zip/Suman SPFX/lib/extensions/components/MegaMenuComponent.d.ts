import * as React from "react";
import { SPHttpClient } from '@microsoft/sp-http';
export interface IMegaMenuComponentState {
    followedSites: any[];
    bookmarkSites: any[];
    profileUrl: string;
    externalSharingDisplayStyle: string;
    primaryOwnerEmail: string;
    primaryOwnerDisplayName: string;
    teamURL: string;
    isTeamExists: boolean;
    isExternallyShared: boolean;
    isLoading: boolean;
    companyLogoUrl: string;
    rootWebUrl: string;
    IsPrimaryOwner: string;
    SiteOwnerGroupInfo: string;
}
export interface IMegaMenuComponentProps {
    email: string;
    webAbsoluteUrl: string;
    SPOHttpClient: SPHttpClient;
}
export default class MegaMenuComponent extends React.Component<IMegaMenuComponentProps, IMegaMenuComponentState> {
    constructor(props: any, state: IMegaMenuComponentState);
    componentDidMount(): void;
    private makeSPHttpClientBatchRequest_AssociatedWeb;
    private makeSPHttpClientBatchRequest_SiteInformationWeb;
    private getAssociatedWebOwnerInformation;
    private getAssociatedWebOwnerGroupMembersInformation;
    private getFollowedSites;
    private invokeRestServices;
    private getBookmarkUserSites;
    private getTeamInfo;
    render(): React.ReactElement<{}>;
}
//# sourceMappingURL=MegaMenuComponent.d.ts.map