declare const styles: {
    'od-ItemsScopeList-page': string;
    'od-ItemsScopeList-content-sticky': string;
    'od-ItemContent-header': string;
    container: string;
    loadersize: string;
    svgLoader: string;
    spin: string;
    divLoader: string;
    teamLiStyle: string;
    'od-ItemContent-title': string;
    liclass: string;
    menusub: string;
    menucategory: string;
    menucol1: string;
    menucol2: string;
    menucol3: string;
    menucol4: string;
    teamliNew: string;
    headerTeam: string;
};
export default styles;
//# sourceMappingURL=MegaMenuComponent.module.scss.d.ts.map