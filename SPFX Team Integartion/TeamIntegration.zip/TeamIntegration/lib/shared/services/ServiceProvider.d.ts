import { WebPartContext } from "@microsoft/sp-webpart-base";
import { MSGraphClient } from "@microsoft/sp-http";
export declare class ServiceProvider {
    _graphClient: MSGraphClient;
    private spcontext;
    constructor(spcontext: WebPartContext);
    getmyTeams: () => Promise<[]>;
    getChannel: (teamID: any) => Promise<[]>;
    sendMessage: (teamId: any, channelId: any, message: any) => Promise<[]>;
}
//# sourceMappingURL=ServiceProvider.d.ts.map