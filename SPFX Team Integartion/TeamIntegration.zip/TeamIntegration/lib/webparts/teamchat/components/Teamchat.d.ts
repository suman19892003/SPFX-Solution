import * as React from 'react';
import { ITeamchatProps } from './ITeamchatProps';
export interface IMyTeamsState {
    myteams: any[];
    selectedTeam: any;
    teamChannels: any;
    selectedChannel: any;
}
export default class Teamchat extends React.Component<ITeamchatProps, IMyTeamsState> {
    private serviceProvider;
    private messageTextRef;
    constructor(props: ITeamchatProps, state: IMyTeamsState);
    private GetmyTeams;
    render(): React.ReactElement<ITeamchatProps>;
    private getChannels;
    private sendMesssage;
}
//# sourceMappingURL=Teamchat.d.ts.map