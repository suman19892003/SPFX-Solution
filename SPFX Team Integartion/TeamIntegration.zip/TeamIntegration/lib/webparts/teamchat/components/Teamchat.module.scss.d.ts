declare const styles: {
    teamchat: string;
    radio: string;
    textbox: string;
    buttons: string;
};
export default styles;
//# sourceMappingURL=Teamchat.module.scss.d.ts.map