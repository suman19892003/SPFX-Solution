declare interface ITeamchatWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TeamchatWebPartStrings' {
  const strings: ITeamchatWebPartStrings;
  export = strings;
}
