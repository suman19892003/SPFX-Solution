/* tslint:disable */
require("./Teamchat.module.css");
const styles = {
  teamchat: 'teamchat_ca828c28',
  radio: 'radio_ca828c28',
  textbox: 'textbox_ca828c28',
  buttons: 'buttons_ca828c28'
};

export default styles;
/* tslint:enable */